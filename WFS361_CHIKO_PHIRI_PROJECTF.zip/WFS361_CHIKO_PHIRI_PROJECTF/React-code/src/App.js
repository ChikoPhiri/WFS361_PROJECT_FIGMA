
import './App.css';
import { Routes, Route } from "react-router-dom";
import Home from '../src/components/Home.jsx'
import About from "../src/components/About.jsx";
import Portfolio from './components/Portfolio.jsx';
import Contact from './components/Contact.jsx';
import Skills from '../src/components/Skills.jsx';
import Eduction from '../src/components/Eduction.jsx'
import NoMatch from '../src/components/NoMatch.jsx'


function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="portfolio" element={<Portfolio />} />
        <Route path="skills" element={<Skills />} />
        <Route path="contact" element={<Contact />} />
        <Route path="education" element={< Eduction/>} />
        <Route path="*" element={<NoMatch />} />
      </Routes>
    </div>
  );
}

export default App;
