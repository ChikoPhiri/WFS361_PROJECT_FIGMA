import React from 'react';
import '../components/CardC.css';

function CardContact(props) {
  return (
    <div className='card-containerC'>
      
      <br />
      <img className='contact-photo' src={props.image} alt={props.title} /><br />
      <h4 className='card-title'>{props.title}</h4>
    </div>
  );
}

export default CardContact;
