import React from 'react';
import '../components/CardE.css';

function CardE(props) {
  return (
    <div>
      <div>
        <h1 id='E-date'>{props.date}</h1>
        <img id='E-image' src={props.image} alt="" />
        <h2 id='E-school'>{props.school}</h2>
        <h2 id='E-school'>{props.qualication}</h2>
      </div>
      <div className="reference">
        <h1 className='sname'>{props.schoolname}</h1>
        <h2 className='n'>{props.name}</h2>
        <h3 className='phone'>{props.phone}</h3>
        <h3 className='email'>{props.email}</h3>
      </div>
    </div>
  );
}

export default CardE;
