import React from 'react'

function NoMatch() {
  return (
    <div>
      No Match
    </div>
  )
}

export default NoMatch
