import reactpic from "../Assest/Reactjs.png";
import html from "../Assest/html.png";
import c from "../Assest/c-sharp.png";
import sql from "../Assest/sql.png";
import Vincent from "../Assest/Vincent.jpeg";
import GDC from "../Assest/gdc.png";
import bc from "../Assest/belgium logo.jpeg";
import photoshop from "../Assest/photoshop.png"
import sketh from '../Assest/skrtchup.png'
import js from '../Assest/js.jpeg'

import fb from "../Assest/facebook.png";
import instagram from "../Assest/instagram.png";
import linkedin from "../Assest/linkedin-logo.png";

import number from "../Assest/phone.png";
import email from "../Assest/email.png";

export const educations = [
  {
    date: "Date: 2014 - 2018",
    image: Vincent,
    school: "School: St Vincent for the deaf ",
    qualication: "Completed Matric",
  },
  {
    date: "Date: 2020 - 2021",
    image: GDC,
    school: "School: Greenside Design Center College",
    qualication: "Completed: Higher Certificate in Design: Interior Design ",
  },
  {
    date: "Date: 2022 - Present",
    image: bc,
    school: "School: Belgium Campus ITversity",
    qualication: "Process Dioplma in IT",
  },
];

export const skills = [
  {
    image: reactpic,
    title: "React",
  },
  {
    image: html,
    title: "HTML",
  },
  {
    image: js,
    title: "SketchUp"
  },
  {
    image: sql,
    title: "SQL Server",
  },
  {
    image: c,
    title: "C#",
  },
  {
    image: photoshop,
    title: "Photoshop",
  },
  {
    image: sketh,
    title: "SketchUp"
  }
  
];

export const media = [
  {
    image: fb,
  },
  {
    image: instagram,
  },
  {
    image: linkedin,
  },
];

export const Contact_details = [
  {
    image: email,
    title: "chiko.phiri00@gmail.com",
  },
  {
    image: number,
    title: "0794880540",
  },
  {
    image: linkedin,
    title: "Chiko Juwa Phiri",
  },
];
export const reference = [
  {
    schoolname: "ST VINCENT SCHOOL",
    name: "principal@stvincentschool.co.za",
    phone: "011 788 5430 | 011 788 5433 | 011 788 5431",
  },
  {
    schoolname: "GREENSIDE DESIGN COLLEGE",
    name: "PROF DES LAUBSCHER",
    phone: "011 646 198",
    email: "info@designcenter.co.za",
  },

  {
    schoolname: "BELGIUM CAMPUS IVERISTY",
    phone: "010 593 5368",
    name: "DR. Theodorus Kritizinger",
    email: "Kririzinger.t@belgiumcampus.ac.za",
  },
];
