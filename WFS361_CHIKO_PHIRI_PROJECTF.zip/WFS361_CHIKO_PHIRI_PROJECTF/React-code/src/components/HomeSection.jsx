import React from 'react';
import '../components/Section.css';
import { Link } from 'react-router-dom';
import myphoto from '../Assest/profile.jpg'; // Update to your edited transparent profile photo path

function HomeSection() {
  const handleDownloadCV = () => {
    // Replace 'src/Assest/Chiko_Phiri_CV.pdf' with the actual path or URL to your CV PDF file
    const downloadUrl = 'public/Chiko_Phiri_CV.pdf';
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.setAttribute('download', true);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  return (
    <div className='home-section'>
      <h1 className='home-chiko'><span>C</span>hiko.Phiri</h1>
      <div className="profile-wrapper">
        <div className="phone-outline">
          <img className="myprofile-work" src={myphoto} alt="Profile" />
        </div>
      </div>
      <section className='left'>
      
        <h2>Software Developer</h2>
        <p>Welcome to my Portfolio</p>
        <div className='button-container'>
          <button className='button-home'>
            <Link to='/about'>
              About
            </Link>
          </button> 
          <button className='button-home'>Hire me </button>
          <button className='button-home' onClick={handleDownloadCV}>
            Download my CV
          </button>
        </div>
      </section>
    </div>
  );
}

export default HomeSection;
