import React from 'react';
import '../components/HeaderAbout.css';
import { Link } from 'react-router-dom';

function HeaderAbout() {
  return (
    <header className='aboutheader'>
      <ul className='ul-header'>
        <Link to='/'>
          <li>Home</li>
        </Link>
        <Link to='/about'>
          <li>About</li>
        </Link>
        <Link to='/portfolio'>
          <li>Resume</li>
        </Link>
        <Link to='/contact'>
          <li>Contact</li>
        </Link>
        <Link to='/skills'>
          <li>Skills</li>
        </Link>
        <Link to='/education'>
          <li>Education</li>
        </Link>
      </ul>
    </header>
  );
}

export default HeaderAbout;
