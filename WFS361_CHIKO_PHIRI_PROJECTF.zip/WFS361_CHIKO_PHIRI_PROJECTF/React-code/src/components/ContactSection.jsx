import React from "react";
import "../components/Contact.css";
import pic from "../Assest/chiko.jpg";
import CardContact from "./CardContact";
import { Contact_details } from "./Data";

function ContactSection() {
  return (
    <div className="contact-container">
      <main className="main-contact">
        <img src={pic} alt="Profile" className="profile-pic" />
        <button className="role-button">Software Developer</button>
        <div className="box-card">
          {Contact_details.map((detail, index) => (
            <CardContact key={index} {...detail} />
          ))}
        </div>
      </main>

      <main className="second">
        <form className="contact-form">
          <h2>Contact Me</h2>
          <input type="text" placeholder="Full name" />
          <input type="email" placeholder="Email Address" />
          <textarea className="f-message" placeholder="Your Message"></textarea>
          <button type="submit" className="submit-button">
            Send Message
          </button>
        </form>
      </main>
    </div>
  );
}

export default ContactSection;
