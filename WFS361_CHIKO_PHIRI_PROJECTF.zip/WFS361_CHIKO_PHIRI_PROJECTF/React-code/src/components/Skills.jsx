import React from 'react';
import Header from './Header';
import SkillSection from './SkillSection';

function Skills() {
  return (
    <div>
      <Header />
      <SkillSection />
    </div>
  );
}

export default Skills;
